﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Commit = '56eddf8cba67a8a477e555b62623e5eaf9bfe116'
$NodeVersion = '22.23.2'
$CoreBaseUrl = 'https://core.vantixgc.com'
$InstallDir = 'C:\ProgramData\VantixGC\Edge'

function Test-Administrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Read-MaskedSecret([string]$Prompt) {
  $secure = Read-Host $Prompt -AsSecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

if (-not (Test-Administrator)) {
  Write-Host ''
  Write-Host 'VantixGC necesita permisos de Administrador para instalar el servicio local.' -ForegroundColor Yellow
  Write-Host 'Cierra esta ventana, haz clic derecho sobre INSTALAR_VANTIXGC_RESTAURANTES.cmd y elige Ejecutar como administrador.'
  Read-Host 'Presiona Enter para salir'
  exit 1
}

Write-Host ''
Write-Host '============================================================' -ForegroundColor DarkGreen
Write-Host ' VantixGC Restaurantes - Instalador oficial Windows' -ForegroundColor Green
Write-Host ' Edge Workspace 2.1.0 - Centro de Control local-first' -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor DarkGreen
Write-Host ''
Write-Host "Destino: $InstallDir"
Write-Host ''

$EdgeAgentId = (Read-Host 'EDGE_AGENT_ID').Trim()
if (-not $EdgeAgentId) { throw 'EDGE_AGENT_ID es obligatorio.' }
$EdgeAgentKey = Read-MaskedSecret 'EDGE_AGENT_KEY'
if (-not $EdgeAgentKey) { throw 'EDGE_AGENT_KEY es obligatorio.' }

$TempRoot = Join-Path $env:TEMP ('VantixGC-Install-' + [guid]::NewGuid().ToString('N'))
$RepoZip = Join-Path $TempRoot 'vantixgc-source.zip'
$NodeZip = Join-Path $TempRoot 'node.zip'
$RepoExtract = Join-Path $TempRoot 'source'
$NodeExtract = Join-Path $TempRoot 'node'

try {
  New-Item -ItemType Directory -Force -Path $TempRoot,$RepoExtract,$NodeExtract | Out-Null

  Write-Host ''
  Write-Host '[1/7] Descargando VantixGC Workspace...' -ForegroundColor Cyan
  $RepoUrl = "https://github.com/juansfer858/saas-backend/archive/$Commit.zip"
  Invoke-WebRequest -Uri $RepoUrl -OutFile $RepoZip -UseBasicParsing
  Expand-Archive -LiteralPath $RepoZip -DestinationPath $RepoExtract -Force
  $RepoRoot = Get-ChildItem -LiteralPath $RepoExtract -Directory | Select-Object -First 1
  if (-not $RepoRoot) { throw 'No fue posible extraer el paquete VantixGC.' }
  $RepoRoot = $RepoRoot.FullName
  $EdgeSource = Join-Path $RepoRoot 'edge'
  if (-not (Test-Path (Join-Path $EdgeSource 'supervisor\install-windows.ps1'))) {
    throw 'El paquete descargado no contiene el instalador Edge esperado.'
  }

  Write-Host '[2/7] Preparando runtime local Node.js...' -ForegroundColor Cyan
  $NodeUrl = "https://nodejs.org/dist/v$NodeVersion/node-v$NodeVersion-win-x64.zip"
  Invoke-WebRequest -Uri $NodeUrl -OutFile $NodeZip -UseBasicParsing
  Expand-Archive -LiteralPath $NodeZip -DestinationPath $NodeExtract -Force
  $NodeRoot = Get-ChildItem -LiteralPath $NodeExtract -Directory | Select-Object -First 1
  if (-not $NodeRoot) { throw 'No fue posible preparar Node.js.' }
  $RuntimeDir = Join-Path $EdgeSource 'runtime'
  New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
  Copy-Item -LiteralPath (Join-Path $NodeRoot.FullName 'node.exe') -Destination (Join-Path $RuntimeDir 'node.exe') -Force

  Write-Host '[3/7] Instalando VantixGC Edge Workspace y Supervisor...' -ForegroundColor Cyan
  & (Join-Path $EdgeSource 'supervisor\install-windows.ps1') `
    -InstallDir $InstallDir `
    -CoreBaseUrl $CoreBaseUrl `
    -EdgeAgentId $EdgeAgentId `
    -EdgeAgentKey $EdgeAgentKey

  Write-Host '[4/7] Configurando acceso seguro y LAN...' -ForegroundColor Cyan
  Write-Host '[5/7] Iniciando servicio local...' -ForegroundColor Cyan
  Start-Sleep -Seconds 3

  Write-Host '[6/7] Verificando Centro de Control...' -ForegroundColor Cyan
  $StatusUrl = 'http://127.0.0.1:8788/api/status'
  $Status = $null
  for ($i=0; $i -lt 30; $i++) {
    try {
      $Status = Invoke-RestMethod -Uri $StatusUrl -Method Get -TimeoutSec 3
      if ($Status.ok) { break }
    } catch {}
    Start-Sleep -Seconds 1
  }
  if (-not $Status -or -not $Status.ok) {
    throw 'VantixGC fue instalado, pero el servicio local no respondió al health check.'
  }

  Write-Host '[7/7] Instalacion completada.' -ForegroundColor Cyan
  Write-Host ''
  Write-Host 'VantixGC Restaurantes quedo instalado correctamente.' -ForegroundColor Green
  Write-Host ('Estado: ' + $Status.mode)
  Write-Host ('Conexion con VantixGC: ' + $Status.connected)
  Write-Host ('Identidad de instalacion: ' + $Status.installationId)
  Write-Host ''
  Write-Host 'Acceso normal del restaurante:' -ForegroundColor Green
  Write-Host 'http://127.0.0.1:8788/app/centro-de-control'
  Write-Host ''
  Write-Host 'Se creo el acceso directo "VantixGC Restaurantes" en el escritorio cuando Windows lo permite.'
  Write-Host 'El Supervisor iniciara automaticamente con Windows.'
  Write-Host ''
} finally {
  Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}

Read-Host 'Presiona Enter para cerrar'
