param(
  [string]$EdgeAgentId = "",
  [string]$CoreBaseUrl = "https://core.vantixgc.com",
  [string]$InstallDir = "C:\ProgramData\VantixGC\Edge"
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Commit = '5574d6e38ce84f64e920f6120c79901fc235fb51'
$NodeVersion = '22.23.2'

function Is-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Is-Admin)) { throw 'Ejecute este instalador como Administrador.' }

Write-Host ''
Write-Host '=============================================' -ForegroundColor DarkGreen
Write-Host ' VantixGC Restaurantes - Instalador Windows' -ForegroundColor Green
Write-Host '=============================================' -ForegroundColor DarkGreen
Write-Host "Destino: $InstallDir"
Write-Host ''

if (-not $EdgeAgentId) { $EdgeAgentId = (Read-Host 'Pegue el EDGE_AGENT_ID suministrado por VantixGC').Trim() }
if (-not $EdgeAgentId) { throw 'EDGE_AGENT_ID es obligatorio.' }

$Secure = Read-Host 'Pegue el EDGE_AGENT_KEY suministrado por VantixGC (no se mostrara)' -AsSecureString
$Ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
try { $EdgeAgentKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($Ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Ptr) }
if (-not $EdgeAgentKey) { throw 'EDGE_AGENT_KEY es obligatorio.' }

$Temp = Join-Path $env:TEMP ('vantixgc-edge-install-' + [guid]::NewGuid().ToString('N'))
$RepoZip = Join-Path $Temp 'repo.zip'; $NodeZip = Join-Path $Temp 'node.zip'
$RepoOut = Join-Path $Temp 'repo'; $NodeOut = Join-Path $Temp 'node'
New-Item -ItemType Directory -Force -Path $Temp,$RepoOut,$NodeOut | Out-Null

try {
  Write-Host '[1/7] Descargando componentes VantixGC...' -ForegroundColor Cyan
  Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/juansfer858/saas-backend/archive/$Commit.zip" -OutFile $RepoZip
  Expand-Archive -LiteralPath $RepoZip -DestinationPath $RepoOut -Force
  $RepoRoot = Get-ChildItem -Path $RepoOut -Directory | Select-Object -First 1
  if (-not $RepoRoot) { throw 'No se pudo preparar el paquete VantixGC.' }
  $EdgeSource = Join-Path $RepoRoot.FullName 'edge'
  if (-not (Test-Path (Join-Path $EdgeSource 'agent\server.js'))) { throw 'El paquete descargado esta incompleto.' }

  Write-Host '[2/7] Preparando runtime local...' -ForegroundColor Cyan
  Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/v$NodeVersion/node-v$NodeVersion-win-x64.zip" -OutFile $NodeZip
  Expand-Archive -LiteralPath $NodeZip -DestinationPath $NodeOut -Force
  $NodeExe = Get-ChildItem -Path $NodeOut -Filter node.exe -Recurse | Select-Object -First 1
  if (-not $NodeExe) { throw 'No se pudo preparar el runtime local.' }
  $RuntimeDir = Join-Path $EdgeSource 'runtime'; New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
  Copy-Item -LiteralPath $NodeExe.FullName -Destination (Join-Path $RuntimeDir 'node.exe') -Force

  Write-Host '[3/7] Instalando VantixGC Edge y Supervisor...' -ForegroundColor Cyan
  & (Join-Path $EdgeSource 'supervisor\install-windows.ps1') -InstallDir $InstallDir -CoreBaseUrl $CoreBaseUrl -EdgeAgentId $EdgeAgentId -EdgeAgentKey $EdgeAgentKey

  $EnvFile = Join-Path $InstallDir '.env'
  if (Test-Path $EnvFile) {
    $Current = Get-Content -LiteralPath $EnvFile
    if ($Current -notmatch '^EDGE_VERSION=') { Add-Content -LiteralPath $EnvFile -Value "EDGE_VERSION=$Commit" -Encoding UTF8 }
  }
  Stop-ScheduledTask -TaskName 'VantixGC Edge Supervisor' -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 1
  Start-ScheduledTask -TaskName 'VantixGC Edge Supervisor'

  Write-Host '[4/7] Configurando acceso seguro en la red local...' -ForegroundColor Cyan
  Get-NetFirewallRule -DisplayName 'VantixGC Edge TCP 8788' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
  Get-NetFirewallRule -DisplayName 'VantixGC Edge Discovery UDP 8789' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
  New-NetFirewallRule -DisplayName 'VantixGC Edge TCP 8788' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8788 -RemoteAddress LocalSubnet -Profile Private,Domain | Out-Null
  New-NetFirewallRule -DisplayName 'VantixGC Edge Discovery UDP 8789' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 8789 -RemoteAddress LocalSubnet -Profile Private,Domain | Out-Null

  Write-Host '[5/7] Iniciando servicio local...' -ForegroundColor Cyan
  $Ok = $false; $Status = $null
  for ($i=0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 1
    try { $Status = Invoke-RestMethod -UseBasicParsing -Uri 'http://127.0.0.1:8788/api/status' -TimeoutSec 2; if ($Status.ok) { $Ok = $true; break } } catch {}
  }
  if (-not $Ok) {
    $Log = Join-Path $InstallDir 'data\supervisor.log'
    if (Test-Path $Log) { Get-Content -LiteralPath $Log -Tail 30 }
    throw 'La instalacion termino, pero el servicio local no paso la comprobacion inicial.'
  }

  Write-Host '[6/7] Verificando instalacion y sincronizacion...' -ForegroundColor Cyan
  if (-not $Status.installationId) { throw 'No se genero la identidad local de instalacion.' }
  if (-not $Status.provisioned) { throw 'La instalacion no quedo vinculada al Super Core.' }

  Write-Host '[7/7] Instalacion completada.' -ForegroundColor Cyan
  Write-Host ''
  Write-Host 'VantixGC Restaurantes quedo instalado correctamente.' -ForegroundColor Green
  Write-Host "Estado: $($Status.mode)"
  Write-Host "Conexion con VantixGC: $($Status.connected)"
  Write-Host "Identidad de instalacion: $($Status.installationId)"
  Write-Host ''
  Write-Host 'Puede cerrar esta ventana.' -ForegroundColor Green
  Read-Host 'Presione ENTER para finalizar'
}
finally {
  $EdgeAgentKey = $null
  Remove-Item -LiteralPath $Temp -Recurse -Force -ErrorAction SilentlyContinue
}
