@echo off
title VantixGC Restaurantes - Instalador
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_VANTIXGC_RESTAURANTES.ps1"
if errorlevel 1 (
  echo.
  echo La instalacion no termino correctamente. Revisa el mensaje anterior.
  pause
)
