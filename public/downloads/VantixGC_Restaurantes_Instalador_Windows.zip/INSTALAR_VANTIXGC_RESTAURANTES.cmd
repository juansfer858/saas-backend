@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR_VANTIXGC_RESTAURANTES.ps1"
if errorlevel 1 (
  echo.
  echo La instalacion no pudo completarse. Tome una foto de este mensaje y contacte soporte VantixGC.
  pause
)
